print(8 / 8)



print(18 % 8)